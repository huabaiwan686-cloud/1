"""上架发送：一组 =（文字 + 混合媒体）打包发到频道，紧跟一条单独验证视频。

发送身份：频道绑定的推送 Bot（Bot HTTP API）。
- 第 1 条：sendMediaGroup（多图相册，caption 带在首图上）/ 无图则 sendMessage 纯文字
- 第 2 条：sendVideo（验证视频，紧随其后）
"""
import io
import json
import logging
import os

import httpx

log = logging.getLogger(__name__)

TG_API = "https://api.telegram.org"

# 分批策略常量（对齐运营代码）
MAX_ALBUM_SIZE = 10  # 相册上限
BIG_IMAGE_SIZE = 10_000_000  # 超 10MB 的图片不进相册，单独发 document
CAPTION_LIMIT = 1024  # caption 上限
TEXT_SEGMENT = 4000  # 超长正文分段长度
BATCH_SLEEP = 1  # 批次间隔秒

import threading
_SEND_LOCKS: dict[str, threading.Lock] = {}
_send_locks_guard = threading.Lock()


def _send_lock(bot_token: str) -> threading.Lock:
    """按 Bot 取发送锁，全局串行化同一 Bot 的发送（防并发撞限流）。"""
    with _send_locks_guard:
        return _SEND_LOCKS.setdefault(bot_token[-8:], threading.Lock())

# _store 的默认落盘目录（与 media.py 保持一致 → backend/uploads）
UPLOAD_DIR = os.environ.get("UPLOAD_DIR", os.path.normpath(
    os.path.join(os.path.dirname(__file__), "..", "..", "uploads")))


def build_caption(title: str = "", body: str = "", tags: list | None = None) -> str:
    parts = []
    if title:
        parts.append(title)
    if body:
        parts.append(body)
    if tags:
        parts.append(" ".join(f"#{t}" for t in tags if t))
    return "\n\n".join(parts)


def _media_bytes(url: str) -> tuple[str, bytes]:
    """媒体 url → (文件名, 二进制)。支持本地 /uploads 路径与 http(s)。"""
    if url.startswith("/uploads/"):
        rel = url.replace("/uploads/", "", 1).lstrip("/")
        rp = os.path.realpath(os.path.join(UPLOAD_DIR, rel))
        if not rp.startswith(os.path.realpath(UPLOAD_DIR)) or not os.path.exists(rp):
            raise FileNotFoundError(f"媒体文件不存在: {url}")
        with open(rp, "rb") as f:
            return os.path.basename(rp), f.read()
    if url.startswith("http://") or url.startswith("https://"):
        r = httpx.get(url, timeout=60)
        r.raise_for_status()
        name = url.split("?")[0].rstrip("/").split("/")[-1] or "media"
        return name, r.content
    raise ValueError(f"不支持的媒体地址: {url}")


def _apply_anti_scan(data: bytes, mode: str, db=None) -> bytes:
    """按频道防扫图模式处理展示图。原图=原图；替换背景/背景虚化=AI处理（含动态随机保护区与内置混淆扰动）。
    若全局防扫图配置启用且 forceBeforeSendEnabled，则叠加全局配置处理。
    """
    out = data
    # 全局防扫图配置
    if db is not None:
        try:
            from app.api.v1.media import get_anti_scan_config
            cfg = get_anti_scan_config(db)
            if cfg.get("globalEnabled") and cfg.get("forceBeforeSendEnabled"):
                from app.services.image_pipeline import apply_anti_scan_config
                out = apply_anti_scan_config(out, cfg)
        except Exception:  # noqa: BLE001
            pass
    return out


def _bot_post(token: str, method: str, data: dict | None = None,
              files: dict | None = None, timeout: int = 120) -> dict:
    r = httpx.post(f"{TG_API}/bot{token}/{method}", data=data or {},
                   files=files, timeout=timeout)
    try:
        payload = r.json()
    except Exception:  # noqa: BLE001
        raise RuntimeError(f"Bot API 返回非 JSON（HTTP {r.status_code}）")
    if not payload.get("ok"):
        raise RuntimeError(f"Bot API 错误: {payload.get('description')}")
    return payload["result"]


def send_listing_set(bot_token: str, chat_id: str, title: str = "", body: str = "",
                     tags: list | None = None, show_media: list | None = None,
                     verify_media: list | None = None,
                     anti_scan_mode: str = "原图",
                     resume: dict | None = None,
                     on_step=None,
                     variation: bool = False,
                     author_user_id: int | None = None,
                     db=None) -> dict:
    """发送一组上架内容。返回 {"media_group_id"/"message_id", "video_message_id"}。

    分步幂等：resume={"album": True} 时跳过已成功的相册，只发验证视频；
    每步成功后调用 on_step("album") / on_step("video")，由调用方持久化进度。
    variation=True 时对文本/图片/视频做无意义微调（防 TG 判重），仅循环重发时用。

    show_media: [{"url":...}] 展示图（混合媒体），最多取 10 张（TG 相册上限）
    verify_media: [{"url":...}] 验证视频，取第 1 个单独发送
    show_media 单项支持：
      - {"url":..., "media_type": "image"|"video"}（NoteMedia / 模板媒体；模板里也可能是 "type" 键）
      - {"data": bytes, "name": ...} 内存图片（全局抠图已处理好，不落盘）→ 按 photo
      - 有 .url / .media_type 属性的对象
    相册内图片/视频可混排（sendMediaGroup 原生支持）。
    author_user_id：笔记作者 id，发布前按其个人水印设置自动叠加水印（P1-14）。
    """
    show_media = show_media or []
    verify_media = verify_media or []
    caption = build_caption(title, body, tags)
    result: dict = {}
    if variation:
        from app.services.variation import vary_text
        caption = vary_text(caption)

    # 个人水印：发送前按作者设置叠加（只对图片，视频跳过）
    # 一次性读取作者水印配置（独立短 session，读完即关）
    _wm_cfg = None
    if author_user_id:
        try:
            from app.core.database import SessionLocal
            from app.models.media import WatermarkSetting
            _s = SessionLocal()
            try:
                _wm_cfg = _s.query(WatermarkSetting).filter(
                    WatermarkSetting.user_id == author_user_id,
                    WatermarkSetting.enabled.is_(True)).first()
                if _wm_cfg:
                    _wm_cfg = {"type": _wm_cfg.type, "content": _wm_cfg.content,
                               "position": _wm_cfg.position,
                               "opacity": float(_wm_cfg.opacity or 70) / 100.0,
                               "qr_size": int(_wm_cfg.qr_size or 100)}
            finally:
                _s.close()
        except Exception:  # noqa: BLE001
            _wm_cfg = None
    if _wm_cfg and _wm_cfg["content"]:
        from app.services.watermark import apply_watermark
        _apply_wm = lambda d: apply_watermark(d, _wm_cfg["type"], _wm_cfg["content"],
                                              _wm_cfg["position"], _wm_cfg["opacity"],
                                              _wm_cfg["qr_size"])
    else:
        _apply_wm = lambda d: d

    # ---- 第 1 组：文字 + 混合媒体分批发送 ----
    # 分批策略（对齐运营代码）：
    # ① 超 10MB 的图片不进相册，单独以 document 发送
    # ② 单张媒体用 sendPhoto/sendVideo，不用 mediaGroup
    # ③ caption 只放第一批并截断 1024 字符
    # ④ 批次之间 sleep(1)
    resume = resume or {}
    result["message_ids"] = []
    with _send_lock(bot_token):
        if show_media and not resume.get("album"):
            # 预处理：读字节 + 防扫 + 变体
            prepared = []
            for m in show_media:
                if isinstance(m, dict) and "data" in m:
                    fname, data = m.get("name", "image.jpg"), m["data"]
                    mtype = "photo"
                else:
                    url = m["url"] if isinstance(m, dict) else m.url
                    mtype_raw = (m.get("media_type") or m.get("type")) if isinstance(m, dict) \
                        else getattr(m, "media_type", "image")
                    mtype = "video" if mtype_raw == "video" else "photo"
                    fname, data = _media_bytes(url)
                    if mtype == "photo":
                        data = _apply_anti_scan(data, anti_scan_mode, db)
                        data = _apply_wm(data)  # 个人水印（P1-14）：按作者设置叠加
                    if variation:
                        from app.services.variation import vary_image, vary_video
                        try:
                            data = vary_video(data) if mtype == "video" else vary_image(data)
                        except Exception:  # noqa: BLE001
                            pass
                oversized = mtype == "photo" and len(data) > BIG_IMAGE_SIZE
                prepared.append({"fname": fname, "data": data, "mtype": mtype,
                                 "oversized": oversized})
            # 分批：超大图单独一批，其余每批最多 10 个
            batches = []
            buf = []
            for p in prepared:
                if p["oversized"]:
                    if buf:
                        batches.append(buf)
                        buf = []
                    batches.append([p])
                else:
                    buf.append(p)
                    if len(buf) >= MAX_ALBUM_SIZE:
                        batches.append(buf)
                        buf = []
            if buf:
                batches.append(buf)
            first_batch = True
            for bi, batch in enumerate(batches):
                files = {f"media{i}": (p["fname"], p["data"]) for i, p in enumerate(batch)}
                cap = caption[:CAPTION_LIMIT] if first_batch and caption else ""
                if len(batch) == 1:
                    p = batch[0]
                    kind = "document" if p["oversized"] else p["mtype"]
                    method = {"photo": "sendPhoto", "video": "sendVideo",
                              "document": "sendDocument"}[kind]
                    payload = {"chat_id": chat_id, kind: "attach://media0"}
                    if cap:
                        payload["caption"] = cap
                    res = _bot_post(bot_token, method, data=payload, files=files)
                    result["message_ids"].append(res.get("message_id"))
                else:
                    media = []
                    for i, p in enumerate(batch):
                        item = {"type": p["mtype"], "media": f"attach://media{i}"}
                        if i == 0 and cap:
                            item["caption"] = cap
                        media.append(item)
                    res = _bot_post(bot_token, "sendMediaGroup",
                                    data={"chat_id": chat_id,
                                          "media": json.dumps(media, ensure_ascii=False)},
                                    files=files)
                    if bi == 0:
                        result["media_group_id"] = res[0].get("media_group_id") if res else None
                    result["message_ids"].extend(m.get("message_id") for m in res)
                first_batch = False
                if bi < len(batches) - 1:
                    import time
                    time.sleep(BATCH_SLEEP)
            if on_step:
                on_step("album")
        elif not show_media:
            res = _bot_post(bot_token, "sendMessage",
                            data={"chat_id": chat_id, "text": caption[:TEXT_SEGMENT] or "(无内容)"})
            result["message_id"] = res.get("message_id")
            result["message_ids"].append(res.get("message_id"))
        # 超长正文（>1024）剩余部分分段补发
        if len(caption) > CAPTION_LIMIT:
            remaining = caption[CAPTION_LIMIT:]
            for i in range(0, len(remaining), TEXT_SEGMENT):
                res = _bot_post(bot_token, "sendMessage",
                                data={"chat_id": chat_id,
                                      "text": remaining[i:i + TEXT_SEGMENT]})
                result["message_ids"].append(res.get("message_id"))

    # ---- 第 2 条：单独验证视频，紧跟其后 ----
    if verify_media and not resume.get("video"):
        v = verify_media[0]
        fname, data = _media_bytes(v["url"] if isinstance(v, dict) else v.url)
        if variation:
            from app.services.variation import vary_video
            try:
                # 视频交替镜像：与图片共用发布计数
                force_mirror = None
                if db is not None:
                    try:
                        from app.models.media import ImageJob
                        pub_count = db.query(ImageJob).filter(
                            ImageJob.source == "publish",
                            ImageJob.mode.in_(["替换背景", "背景虚化"])
                        ).count()
                        force_mirror = (pub_count % 2 == 0)
                    except Exception:
                        pass
                data = vary_video(data, force_mirror=force_mirror)
            except Exception:  # noqa: BLE001
                pass
        res = _bot_post(bot_token, "sendVideo",
                        data={"chat_id": chat_id},
                        files={"video": (fname, data)})
        result["video_message_id"] = res.get("message_id")
        if on_step:
            on_step("video")

    return result


def matt_for_publish(data: bytes, bg_data: bytes | None, db, user=None, mode: str = "替换背景", background_id: int | None = None) -> bytes:
    """全局抠图（发布时用）：内存中处理，**不落盘**；服务器只保留原图。

    mode: replace_bg | blur_bg | original
    - original：直接返回原图
    - 表格/自评表：返回原图，不扣额度（与手动处理一致）
    - 抠图服务未配置：返回原图，不中断上架
    - 额度：同一原图首次成功扣 1 次，重复图不重复扣（与手动处理共用去重规则）；
      额度不足时返回原图（不推理、不扣费），不中断上架
    - 写 ImageJob 审计行（result_url 为空，表示处理图未留存）
    """
    import hashlib

    from PIL import Image as PILImage

    from app.models.media import ImageJob
    from app.services.image_pipeline import blur_background, replace_background
    from app.services.matting import is_table_image

    if mode == "原图":
        return data
    src_hash = hashlib.sha256(data).hexdigest()
    try:
        probe = PILImage.open(io.BytesIO(data)).convert("RGB")
        if is_table_image(probe):
            return data
    except Exception:  # noqa: BLE001
        pass
    # 去重扣额度（与 /api/media/process 共用规则）
    dup = db.query(ImageJob).filter(
        ImageJob.mode.in_(["替换背景", "背景虚化"]),
        ImageJob.status == "success",
        ImageJob.quota_consumed.is_(True),
        ImageJob.detail.contains(src_hash),
    ).first()
    if not dup:
        from app.api.v1.vip import quota_available

        if not quota_available(db, 1, user):
            # 额度不足 → 返回原图，不扣费、不中断上架
            db.add(ImageJob(mode=mode, status="success", source="publish",
                            result_url="", quota_consumed=False, fallback=True,
                            detail=f"quota_exhausted:{src_hash}"))
            db.flush()
            return data
    try:
        import random
        # 强制交替镜像计数（替换和虚化共用）
        from app.models.media import ImageJob
        pub_count = db.query(ImageJob).filter(
            ImageJob.source == "publish",
            ImageJob.mode.in_(["替换背景", "背景虚化"])
        ).count()
        force_mirror = (pub_count % 2 == 0)
        if mode == "背景虚化":
            # 强几何（只镜像）+ 随机模糊强度，保证每次输出不同
            out, margin_info = blur_background(data, {
                "strong_geo": True,
                "mirror_only": True,
                "force_mirror": force_mirror,
                "blur_radius": random.uniform(8, 16)
            })
        else:
            # 背景选择逻辑：
            # - 如果用户在后台指定了自定义背景（background_id 对应 category='custom'）→ 固定用那张
            # - 否则 → 从默认8张白色里随机
            from app.models.media import BackgroundMaterial
            use_fixed = False
            if background_id:
                bg_rec = db.query(BackgroundMaterial).filter(BackgroundMaterial.id == background_id).first()
                if bg_rec and bg_rec.category == "custom":
                    use_fixed = True  # 用户指定的自定义背景，固定使用
            if not use_fixed:
                # 随机从默认白色背景里选
                bgs = db.query(BackgroundMaterial).filter(BackgroundMaterial.category == "default").all()
                if bgs:
                    bg_choice = random.choice(bgs)
                    try:
                        from app.api.v1.media import _media_bytes_local
                        _, bg_data = _media_bytes_local(bg_choice.url)
                    except Exception:
                        pass  # 用传入的默认背景
            # force_mirror 已在上方按发布次数奇偶计算
            # mirror_only: 只镜像不位移，人物画质零损失
            out, margin_info = replace_background(data, bg_data, {
                "strong_geo": True,
                "mirror_only": True,
                "force_mirror": force_mirror,
                "bg_texture": True
            })
    except NotImplementedError:
        return data
    quota_consumed = False
    if not dup:
        from app.api.v1.vip import consume_quota
        ok_q, _ = consume_quota(db, 1, user)
        quota_consumed = ok_q
    db.add(ImageJob(mode=mode, status="success", source="publish",
                    result_url="", quota_consumed=quota_consumed,
                    detail=f"publish_matting:{src_hash}"))
    db.flush()
    return out
