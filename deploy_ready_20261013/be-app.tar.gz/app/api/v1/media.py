"""图片处理接口：/api/media/*（素材库 / 处理任务）。

模式：
- replace_bg：人像背景替换（含动态随机保护区，扣额度）
- blur_bg：人像背景虚化（含动态随机保护区，扣额度）
- original：原图
表格/自评表类截图本地识别后直接返回原图，不扣额度。
"""
import hashlib
import io
import os
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from PIL import Image as PILImage
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.permissions import require_admin, require_member
from app.api.deps import get_current_user, ok
from app.api.v1.vip import consume_quota, quota_available
from app.core.database import get_db
from app.models.media import BackgroundMaterial, GlobalSetting, ImageJob
from app.models.user import User
from app.services.image_pipeline import blur_background, replace_background
from app.services.matting import is_table_image

router = APIRouter(prefix="/media", tags=["media"])

MATTING_MODES = {"替换背景", "背景虚化"}

UPLOAD_DIR = os.environ.get(
    "UPLOAD_DIR",
    os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "uploads")),
)
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(os.path.join(UPLOAD_DIR, "results"), exist_ok=True)


def _store(data: bytes, subdir: str = "", suffix: str = ".jpg") -> tuple[str, str]:
    """保存文件，返回 (fs_path, web_path)。web_path 供浏览器直接访问。"""
    name = f"{uuid.uuid4().hex}{suffix}"
    rel = f"{subdir}/{name}" if subdir else name
    fs_path = os.path.join(UPLOAD_DIR, rel)
    os.makedirs(os.path.dirname(fs_path), exist_ok=True)
    with open(fs_path, "wb") as f:
        f.write(data)
    return fs_path, "/uploads/" + rel


def _fs_path(web_path: str) -> str:
    """web_path → 文件系统路径（限 uploads 目录内，防止路径穿越）。"""
    rel = web_path.replace("/uploads/", "", 1).lstrip("/")
    rp = os.path.realpath(os.path.join(UPLOAD_DIR, rel))
    if not rp.startswith(os.path.realpath(UPLOAD_DIR)):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "非法路径")
    return rp


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@router.post("/materials")
async def upload_material(
    file: UploadFile = File(...),
    name: str = Form("未命名素材"),
    category: str = Form("default"),
    user: User = Depends(require_member),
    db: Session = Depends(get_db),
):
    # 分块读取 + 大小上限（200MB），防超大文件打爆内存
    chunks, total = [], 0
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > 200 * 1024 * 1024:
            raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "文件过大（上限 200MB）")
        chunks.append(chunk)
    data = b"".join(chunks)
    suffix = os.path.splitext(file.filename or "")[1].lower() or ".jpg"
    # 素材上传：图片（背景/展示图）+ MP4（验证视频）
    if suffix not in (".jpg", ".jpeg", ".png", ".webp", ".mp4"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "仅支持 JPG/PNG/WebP/MP4 格式")
    _, web_path = _store(data, suffix=suffix)
    m = BackgroundMaterial(name=name, url=web_path, category=category)
    db.add(m)
    db.commit()
    return ok({"id": m.id, "name": m.name, "url": m.url}, msg="素材已上传")


@router.get("/materials")
def list_materials(user: User = Depends(require_member), db: Session = Depends(get_db)):
    ms = db.query(BackgroundMaterial).order_by(BackgroundMaterial.id.desc()).all()
    # 仅返回图片格式的背景素材，过滤掉误上传的视频
    result = []
    for m in ms:
        url_lower = (m.url or "").lower()
        if url_lower.endswith((".jpg", ".jpeg", ".png", ".webp", ".gif")):
            result.append({"id": m.id, "name": m.name, "url": m.url, "category": m.category})
    return ok(result)


@router.delete("/materials/{material_id}")
def delete_material(material_id: int, user: User = Depends(require_member), db: Session = Depends(get_db)):
    m = db.query(BackgroundMaterial).filter(BackgroundMaterial.id == material_id).first()
    if not m:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "素材不存在")
    # 同步删除磁盘文件，避免残留
    try:
        rel = (m.url or "").replace("/uploads/", "", 1).lstrip("/")
        rp = os.path.realpath(os.path.join(UPLOAD_DIR, rel))
        if rel and rp.startswith(os.path.realpath(UPLOAD_DIR)) and os.path.isfile(rp):
            os.remove(rp)
    except Exception:  # noqa: BLE001
        pass
    db.delete(m)
    db.commit()
    return ok(msg="素材已删除")


@router.post("/process")
async def process_image(
    file: UploadFile = File(...),
    mode: str = Form("替换背景"),  # replace_bg/blur_bg/original
    background_id: int | None = Form(None),
    blur_radius: float = Form(12),
    random_geo: bool = Form(False),  # 随机几何变换（去重对抗测试）
    bg_texture: bool = Form(False),  # 背景强纹理+随机光照（去重对抗测试）
    user: User = Depends(require_member),
    db: Session = Depends(get_db),
):
    if mode not in ("替换背景", "背景虚化", "原图"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"未知处理模式：{mode}")
    # 分块读取 + 大小上限（200MB）
    chunks, total = [], 0
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > 200 * 1024 * 1024:
            raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "文件过大（上限 200MB）")
        chunks.append(chunk)
    data = b"".join(chunks)
    src_hash = _sha256(data)
    job = ImageJob(mode=mode, source=f"upload:{file.filename}")
    fallback = False
    quota_consumed = False
    reuse_result: str | None = None  # 缓存命中时直接复用，不重新推理

    try:
        if mode == "原图":
            out = data
        elif mode in MATTING_MODES:
            bg_data = None
            if mode == "替换背景":
                bg = db.query(BackgroundMaterial).filter(BackgroundMaterial.id == background_id).first()
                if not bg:
                    raise HTTPException(status.HTTP_400_BAD_REQUEST, "背景素材不存在")
                bg_fs = _fs_path(bg.url)
                if not os.path.exists(bg_fs):
                    raise HTTPException(status.HTTP_400_BAD_REQUEST, "背景素材不存在")
                with open(bg_fs, "rb") as f:
                    bg_data = f.read()
            # 缓存键：模式 + 原图哈希 + 参数（虚化半径/背景 id）；先查缓存，命中则连 PIL 解码都省了
            # random_geo/bg_texture=True 时不走缓存，每次都要重新随机生成
            cache_key = f"{mode}:{src_hash}:r{blur_radius}" if mode == "背景虚化" else f"{mode}:{src_hash}:bg{background_id}:geo{int(random_geo)}:tex{int(bg_texture)}"
            hit = None
            if not (random_geo or bg_texture):
                hit = db.query(ImageJob).filter(
                    ImageJob.status == "success",
                    ImageJob.detail.contains(cache_key),
                ).first()
            hit_fs = _fs_path(hit.result_url) if hit and hit.result_url else ""
            if hit and hit_fs and os.path.isfile(hit_fs):
                # 命中：直接复用上次结果，不推理、不扣额度
                reuse_result = hit.result_url
                job.detail = f"cache_hit:{cache_key}"
            else:
                probe = PILImage.open(io.BytesIO(data)).convert("RGB")
                if is_table_image(probe):
                    # 表格/自评表：本地识别，直接返回原图，不扣额度
                    out = data
                    job.detail = f"table_skipped:{src_hash}"
                else:
                    # 去重：同一原图首次成功才扣额度，重复图不重复扣
                    dup = db.query(ImageJob).filter(
                        ImageJob.mode.in_(list(MATTING_MODES)),
                        ImageJob.status == "success",
                        ImageJob.quota_consumed.is_(True),
                        ImageJob.detail.contains(src_hash),
                    ).first()
                    if not dup and not quota_available(db, 1, user):
                        # 额度不足 → 返回原图（不推理、不扣费）
                        out = data
                        fallback = True
                        job.detail = f"quota_exhausted:{src_hash}"
                    else:
                        try:
                            if mode == "背景虚化":
                                out, proc_info = blur_background(data, {"blur_radius": blur_radius})
                            else:
                                out, proc_info = replace_background(data, bg_data, {"random_geo": random_geo, "bg_texture": bg_texture})
                            # 首次成功抠图才扣额度；缓存命中/重复图不重复扣
                            if not dup:
                                ok_q, _ = consume_quota(db, 1, user)
                                quota_consumed = ok_q
                            job.detail = f"{cache_key}|provider:{proc_info.get('provider')}|mask_validated:{proc_info.get('mask_validated')}"
                        except NotImplementedError:
                            # 抠图服务未配置 → 返回原图（不扣额度）
                            out = data
                            fallback = True
                            job.detail = f"matting_unavailable:{src_hash}"
        # original 模式在上方已处理（out = data）

        if reuse_result:
            job.status = "success"
            job.result_url = reuse_result
        else:
            _, result_web = _store(out, subdir="results")
            job.status = "success"
            job.result_url = result_web
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        job.status = "failed"
        job.detail = f"{type(e).__name__}: {e}"

    job.quota_consumed = quota_consumed
    job.fallback = fallback
    job.background_id = background_id
    if job.status == "success" and not job.detail:
        job.detail = src_hash
    db.add(job)
    db.commit()
    return ok({
        "jobId": job.id, "mode": mode, "status": job.status,
        "resultUrl": job.result_url, "quotaConsumed": quota_consumed,
        "fallback": fallback, "tableSkipped": job.detail.startswith("table_skipped") if job.detail else False,
        "cacheHit": reuse_result is not None,
    }, msg="处理完成" if job.status == "success" else "处理失败")


@router.get("/jobs")
def list_jobs(user: User = Depends(require_member), db: Session = Depends(get_db)):
    jobs = db.query(ImageJob).order_by(ImageJob.id.desc()).limit(100).all()
    return ok([{
        "id": j.id, "mode": j.mode, "status": j.status,
        "resultUrl": j.result_url, "quotaConsumed": bool(j.quota_consumed),
        "fallback": bool(j.fallback),
    } for j in jobs])


@router.get("/thumb")
def thumb(
    src: str = Query(..., description="web 路径，如 /uploads/results/xxx.jpg"),
    w: int = Query(400, ge=64, le=1200, description="缩略图宽度"),
):
    """图片缩略图（画廊列表用）：按宽度等比缩放，磁盘缓存。

    注：有意不鉴权——<img> 标签无法携带 Authorization 头；
    路径为不可猜测的 UUID，与 /uploads 静态目录的暴露面一致。
    """
    from fastapi.responses import FileResponse

    from PIL import Image as PILImage

    fs_path = _fs_path(src)
    if not os.path.isfile(fs_path):
        raise HTTPException(status.HTTP_404_NOT_FOUND, "图片不存在")
    cache_dir = os.path.join(UPLOAD_DIR, "thumbs")
    os.makedirs(cache_dir, exist_ok=True)
    key = hashlib.sha256(f"{os.path.realpath(fs_path)}:{w}".encode()).hexdigest()
    cached = os.path.join(cache_dir, f"{key}.jpg")
    if not os.path.exists(cached):
        img = PILImage.open(fs_path).convert("RGB")
        if img.width > w:
            img = img.resize((w, int(img.height * w / img.width)), PILImage.LANCZOS)
        img.save(cached, "JPEG", quality=82)
    return FileResponse(cached, media_type="image/jpeg")


class MattingGlobalIn(BaseModel):
    enabled: bool
    background_id: int | None = None
    mode: str = "替换背景"  # replace_bg | blur_bg | original


def _get_setting(db: Session, key: str, default: str = "") -> str:
    r = db.query(GlobalSetting).filter(GlobalSetting.key == key).first()
    return r.value if r else default


def _set_setting(db: Session, key: str, value: str) -> None:
    r = db.query(GlobalSetting).filter(GlobalSetting.key == key).first()
    if r:
        r.value = value
    else:
        db.add(GlobalSetting(key=key, value=value))


def get_matting_global(db: Session) -> dict | None:
    """全局抠图配置：启用返回 {"mode", "background_id", "bg_data"}，否则 None。"""
    if _get_setting(db, "matting_global_enabled") != "1":
        return None
    mode = _get_setting(db, "matting_global_mode", "替换背景")
    if mode not in ("替换背景", "背景虚化", "原图"):
        mode = "替换背景"
    bg_id, bg_data = None, None
    if mode == "替换背景":
        try:
            bg_id = int(_get_setting(db, "matting_global_background_id") or 0)
        except ValueError:
            return None
        bg = db.query(BackgroundMaterial).filter(BackgroundMaterial.id == bg_id).first()
        if not bg:
            return None
        try:
            _, bg_data = _media_bytes_local(bg.url)
        except Exception:  # noqa: BLE001
            return None
    return {"mode": mode, "background_id": bg_id, "bg_data": bg_data}


def _media_bytes_local(url: str) -> tuple[str, bytes]:
    rel = url.replace("/uploads/", "", 1).lstrip("/")
    rp = os.path.realpath(os.path.join(UPLOAD_DIR, rel))
    if not rp.startswith(os.path.realpath(UPLOAD_DIR)) or not os.path.isfile(rp):
        raise FileNotFoundError(f"背景素材不存在: {url}")
    with open(rp, "rb") as f:
        return os.path.basename(rp), f.read()


@router.get("/matting-global")
def get_matting_global_ep(user: User = Depends(require_member), db: Session = Depends(get_db)):
    enabled = _get_setting(db, "matting_global_enabled") == "1"
    mode = _get_setting(db, "matting_global_mode", "替换背景")
    try:
        bg_id = int(_get_setting(db, "matting_global_background_id") or 0) or None
    except ValueError:
        bg_id = None
    bg = db.query(BackgroundMaterial).filter(BackgroundMaterial.id == bg_id).first() if bg_id else None
    return ok({"enabled": enabled, "mode": mode, "backgroundId": bg_id,
               "backgroundName": bg.name if bg else "",
               "backgroundUrl": bg.url if bg else ""})


@router.post("/matting-global")
def set_matting_global_ep(body: MattingGlobalIn, user: User = Depends(require_member),
                          db: Session = Depends(get_db)):
    if body.mode not in ("替换背景", "背景虚化", "原图"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "不支持的抠图模式")
    if body.enabled and body.mode == "替换背景":
        if not body.background_id:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "请先选择抠图背景素材")
        bg = db.query(BackgroundMaterial).filter(BackgroundMaterial.id == body.background_id).first()
        if not bg:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "背景素材不存在")
    _set_setting(db, "matting_global_enabled", "1" if body.enabled else "0")
    _set_setting(db, "matting_global_mode", body.mode)
    _set_setting(db, "matting_global_background_id", str(body.background_id or ""))
    db.commit()
    return ok(msg="全局抠图模式已" + ("开启" if body.enabled else "关闭"))


@router.post("/dedup-check")
async def dedup_check(
    file: UploadFile = File(...),
    user: User = Depends(require_member),
):
    """上传一张图片，返回其 dHash（用于去重比对）。"""
    from app.services.dedup import dhash_bytes, hamming_distance

    chunks, total = [], 0
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > 50 * 1024 * 1024:
            raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "文件过大（上限 50MB）")
        chunks.append(chunk)
    data = b"".join(chunks)
    try:
        h = dhash_bytes(data)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"图片解析失败：{e}")
    return ok({"dhash": format(h, "016x"), "dhash_int": str(h)})


@router.post("/dedup-scan")
def dedup_scan_materials(
    threshold: int = 5,
    user: User = Depends(require_member),
    db: Session = Depends(get_db),
):
    """扫描素材库中的重复图片（dHash 汉明距离 <= threshold）。"""
    from app.services.dedup import dhash_file, find_duplicates

    materials = db.query(BackgroundMaterial).all()
    paths: list[str] = []
    id_by_path: dict[str, int] = {}
    for m in materials:
        try:
            fp = _fs_path(m.url)
        except Exception:  # noqa: BLE001
            continue
        if os.path.isfile(fp):
            paths.append(fp)
            id_by_path[fp] = m.id
    groups = find_duplicates(paths, threshold=threshold)
    out = []
    for g in groups:
        out.append([{"id": id_by_path[p], "path": p} for p in g])
    return ok({"groups": out, "group_count": len(out), "scanned": len(paths)})


# ============ 个人水印设置（P1-13 / P1-14）============

class WatermarkSettingIn(BaseModel):
    type: str = "text"          # text | qr
    content: str = ""           # 文字内容 或 二维码数据
    position: str = "bottom-right"  # top-left/top-right/bottom-left/bottom-right/center
    opacity: int = 70           # 0-100
    qr_size: int = 100
    enabled: bool = False


class WatermarkPreviewIn(BaseModel):
    type: str = "text"
    content: str = ""
    position: str = "bottom-right"
    opacity: int = 70
    qr_size: int = 100


@router.get("/watermark-setting")
def get_watermark_setting(user: User = Depends(require_member),
                          db: Session = Depends(get_db)):
    """获取当前登录用户的个人水印设置。"""
    from app.models.media import WatermarkSetting
    s = db.query(WatermarkSetting).filter(WatermarkSetting.user_id == user.id).first()
    if not s:
        return ok({"type": "text", "content": "", "position": "bottom-right",
                   "opacity": 70, "qr_size": 100, "enabled": False})
    return ok({"type": s.type, "content": s.content, "position": s.position,
               "opacity": int(s.opacity or 70), "qr_size": int(s.qr_size or 100),
               "enabled": bool(s.enabled)})


@router.post("/watermark-setting")
def set_watermark_setting(body: WatermarkSettingIn, user: User = Depends(require_member),
                          db: Session = Depends(get_db)):
    """保存当前登录用户的个人水印设置（按作者覆盖）。"""
    from app.models.media import WatermarkSetting
    if body.type not in ("text", "qr"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "type 只能是 text 或 qr")
    if body.position not in ("top-left", "top-right", "bottom-left", "bottom-right", "center"):
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "position 非法")
    if body.enabled and not body.content:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "启用水印前请填写水印内容")
    s = db.query(WatermarkSetting).filter(WatermarkSetting.user_id == user.id).first()
    if not s:
        s = WatermarkSetting(user_id=user.id)
        db.add(s)
    s.type = body.type
    s.content = body.content
    s.position = body.position
    s.opacity = max(0, min(100, body.opacity))
    s.qr_size = max(48, min(300, body.qr_size))
    s.enabled = body.enabled
    db.commit()
    return ok(msg="水印设置已保存")


@router.post("/watermark-preview")
async def watermark_preview(file: UploadFile = File(...),
                            type: str = Form("text"),
                            content: str = Form(""),
                            position: str = Form("bottom-right"),
                            opacity: int = Form(70),
                            qr_size: int = Form(100),
                            user: User = Depends(require_member)):
    """上传图片 + 水印参数，返回叠加水印后的预览图（base64 data URL）。"""
    from app.services.watermark import apply_watermark
    if not content:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "请填写水印内容")
    raw = await file.read()
    out = apply_watermark(raw, type, content, position, opacity / 100.0, qr_size)
    import base64
    data_url = "data:image/jpeg;base64," + base64.b64encode(out).decode()
    return ok({"preview": data_url})


@router.post("/image-search")
async def image_search(
    file: UploadFile = File(...),
    page: int = Form(1),
    per_page: int = Form(20),
    threshold: int = Form(10),
    user: User = Depends(require_member),
    db: Session = Depends(get_db),
):
    """以图搜图：上传一张图片，在笔记素材中找相似图（dHash 海明距离）。
    原站对标：POST /follow/note/image-search
    """
    from app.models.content import Note, NoteMedia
    from app.services.dedup import dhash_bytes, hamming_distance

    data = await file.read()
    if len(data) > 50 * 1024 * 1024:
        raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "文件过大（上限 50MB）")
    try:
        query_hash = dhash_bytes(data)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"图片解析失败：{e}")

    # 遍历所有图片素材计算相似度（数据量大时可加缓存优化）
    medias = db.query(NoteMedia).filter(NoteMedia.media_type == "image").all()
    hits = []
    for m in medias:
        try:
            fp = _fs_path(m.url)
            if not os.path.exists(fp):
                continue
            with open(fp, "rb") as f:
                h = dhash_bytes(f.read())
            dist = hamming_distance(query_hash, h)
            if dist <= threshold:
                hits.append((dist, m))
        except Exception:  # noqa: BLE001
            continue
    hits.sort(key=lambda x: x[0])
    total = len(hits)
    start = (page - 1) * per_page
    page_hits = hits[start:start + per_page]
    # 取关联笔记信息
    note_ids = list({m.note_id for _, m in page_hits})
    notes = {n.id: n for n in db.query(Note).filter(Note.id.in_(note_ids)).all()} if note_ids else {}
    items = []
    for dist, m in page_hits:
        n = notes.get(m.note_id)
        items.append({
            "note_id": m.note_id,
            "note_title": n.title if n else "",
            "media_url": m.url,
            "distance": dist,
        })
    return ok({"total": total, "page": page, "per_page": per_page, "items": items})


# ============ 防扫图完整配置（对标原站 30+ 字段） ============

ANTI_SCAN_DEFAULTS = {
    "globalEnabled": False,
    "allowSingleOverrideEnabled": False,
    "forceBeforeSendEnabled": False,
    "existingBatchEnabled": False,
    # 基础保护
    "metadataStripEnabled": False,
    "compressionEnabled": False,
    "compressionQuality": 82,
    "resizeEnabled": False,
    "resizeScale": 96,
    "cropEnabled": False,
    "cropPercent": 2,
    "jpegQualityControlEnabled": False,
    # 图像扰动
    "noiseEnabled": False,
    "noiseStrength": 18,
    "colorJitterEnabled": False,
    "colorJitterStrength": 12,
    "sharpenBlurEnabled": False,
    "sharpenBlurMode": "blur",
    "sharpenBlurStrength": 8,
    # 背景水印
    "backgroundReplaceEnabled": False,
    "backgroundReplaceVipEnabled": False,
    "backgroundBlurEnabled": False,
    "portraitBackgroundEnabled": False,
    "portraitSoftEdgeEnabled": False,
    "portraitSoftEdgeWidth": 12,
    "originalOverlayEnabled": False,
    "originalOverlayOpacity": 92,
    "originalOverlayWidth": 72,
    "backgroundTextureEnabled": False,
    "backgroundTexturePreset": "rabbit",
    "backgroundTextureImage": "",
    "watermarkEnabled": False,
    "watermarkText": "xiaohuiji",
    "watermarkFontSize": 20,
    "watermarkOpacity": 20,
    "profileNoWatermarkEnabled": False,
    # 遮罩/二维码/贴图
    "maskEnabled": False,
    "maskMode": "qr",
    "maskCount": 1,
    "maskOpacity": 42,
    "maskItemsJson": "[]",
    "qrText": "",
    "stickerImage": "",
    "stickerText": "",
}

# 内置背景纹理 SVG（从原站前端提取）
ANTI_SCAN_TEXTURES = {
    "dot": None, "grid": None, "heart": None, "rabbit": None,
}


def _load_textures():
    if ANTI_SCAN_TEXTURES["dot"]:
        return
    import pathlib
    base = pathlib.Path(__file__).resolve().parents[3] / "docs" / "reverse"
    for name in ANTI_SCAN_TEXTURES:
        p = base / f"texture-{name}.svg"
        if p.exists():
            ANTI_SCAN_TEXTURES[name] = p.read_text(encoding="utf-8")


def get_anti_scan_config(db: Session) -> dict:
    import json
    raw = _get_setting(db, "anti_scan_config", "")
    cfg = dict(ANTI_SCAN_DEFAULTS)
    if raw:
        try:
            saved = json.loads(raw)
            cfg.update({k: v for k, v in saved.items() if k in ANTI_SCAN_DEFAULTS})
        except Exception:  # noqa: BLE001
            pass
    return cfg


@router.get("/anti-scan")
def get_anti_scan(user: User = Depends(require_member), db: Session = Depends(get_db)):
    return ok(get_anti_scan_config(db))


@router.post("/anti-scan")
def set_anti_scan(body: dict, user: User = Depends(require_admin), db: Session = Depends(get_db)):
    import json
    cfg = dict(ANTI_SCAN_DEFAULTS)
    cfg.update({k: v for k, v in (body or {}).items() if k in ANTI_SCAN_DEFAULTS})
    # 联动：开启背景替换 → 纹理开、水印关；关闭 → 相关全关
    if cfg.get("backgroundReplaceEnabled"):
        cfg["backgroundTextureEnabled"] = True
        cfg["watermarkEnabled"] = False
        cfg["profileNoWatermarkEnabled"] = False
    else:
        cfg["backgroundTextureEnabled"] = False
        cfg["originalOverlayEnabled"] = False
        cfg["portraitSoftEdgeEnabled"] = False
    _set_setting(db, "anti_scan_config", json.dumps(cfg, ensure_ascii=False))
    db.commit()
    return ok(msg="防扫图配置已保存")


@router.get("/anti-scan/textures")
def list_anti_scan_textures(user: User = Depends(require_member)):
    """返回内置背景模板（含人物背景模糊）。"""
    import base64
    _load_textures()
    out = []
    labels = {"rabbit": "粉色贴图", "heart": "爱心纹理", "dot": "点阵纹理", "grid": "网格纹理",
              "blur": "人物背景模糊"}
    for name, label in labels.items():
        svg = ANTI_SCAN_TEXTURES.get(name) or ""
        data_url = ""
        if svg:
            data_url = "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode()
        out.append({"name": name, "label": label, "preview": data_url,
                    "is_blur": name == "blur"})
    return ok(out)
