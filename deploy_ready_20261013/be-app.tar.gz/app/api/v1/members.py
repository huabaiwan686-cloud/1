"""会员管理：/api/members/*（仅超管 dah86586 可访问）。

- 会员列表（不含超管自己）
- 删除会员（连同其所有数据）
- 设置/修改会员到期时间
"""
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, ok
from app.core.database import get_db
from app.core.permissions import require_admin
from app.models.billing import InviteCode, InviteRecord
from app.models.user import User

router = APIRouter(prefix="/members", tags=["members"])

SUPER_ADMIN = "dah86586"


def _require_super(user: User) -> None:
    if user.username != SUPER_ADMIN:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "仅超管可操作")


class ExpireIn(BaseModel):
    days: int = 0  # 0=永久，>0=从现在起N天，<0=已过期


class RenewIn(BaseModel):
    invite_code: str  # 续费用的一次性邀请码


@router.post("/renew")
def renew_membership(body: RenewIn, user: User = Depends(get_current_user),
                     db: Session = Depends(get_db)):
    """会员用新邀请码续费 30 天（一次性码，用后作废）。"""
    code_str = (body.invite_code or "").strip().upper()
    if not code_str:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "请填写邀请码")
    code_row = db.query(InviteCode).filter(InviteCode.code == code_str).first()
    if not code_row:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "邀请码不存在")
    if code_row.used:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "邀请码已使用")
    # 从当前到期时间续 30 天（若已过期则从现在起算）
    base = max(user.member_expires_at or datetime.utcnow(), datetime.utcnow())
    user.member_expires_at = base + timedelta(days=30)
    user.is_member = True
    code_row.used = True
    code_row.used_by = user.username
    db.add(InviteRecord(code=code_str, invitee=user.username, note="renew"))
    db.commit()
    return ok(msg=f"续费成功，会员有效期至 {user.member_expires_at.strftime('%Y-%m-%d')}")


@router.get("/list")
def list_members(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    _require_super(user)
    users = db.query(User).filter(User.username != SUPER_ADMIN).order_by(User.id.desc()).all()
    return ok([{
        "id": u.id,
        "username": u.username,
        "displayName": u.display_name,
        "isActive": u.is_active,
        "isMember": u.is_member,
        "memberExpiresAt": u.member_expires_at.isoformat() if u.member_expires_at else None,
        "createdAt": u.created_at.isoformat() if u.created_at else None,
    } for u in users])


@router.post("/{user_id}/expire")
def set_expire(user_id: int, body: ExpireIn, user: User = Depends(require_admin),
               db: Session = Depends(get_db)):
    _require_super(user)
    target = db.query(User).filter(User.id == user_id).first()
    if not target or target.username == SUPER_ADMIN:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "会员不存在")
    if body.days == 0:
        target.member_expires_at = None
        target.is_member = True
    elif body.days > 0:
        target.member_expires_at = datetime.utcnow() + timedelta(days=body.days)
        target.is_member = True
    else:
        target.member_expires_at = datetime.utcnow() + timedelta(days=body.days)
        target.is_member = False
    db.commit()
    return ok(msg=f"已设置 {target.username} 的使用期限")


@router.delete("/{user_id}")
def delete_member(user_id: int, user: User = Depends(require_admin),
                  db: Session = Depends(get_db)):
    """删除会员及其所有数据（笔记、媒体、频道等）。"""
    _require_super(user)
    target = db.query(User).filter(User.id == user_id).first()
    if not target or target.username == SUPER_ADMIN:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "会员不存在")
    # 删除该用户的所有数据
    from app.models.content import Note, NoteMedia
    from app.models.distribution import Channel
    import os
    from app.api.v1.media import _fs_path
    # 删除笔记文件
    for m in db.query(NoteMedia).join(Note, NoteMedia.note_id == Note.id).filter(Note.created_by == target.id).all():
        try:
            fp = _fs_path(m.url)
            if os.path.exists(fp):
                os.remove(fp)
        except Exception:
            pass
    db.query(NoteMedia).filter(NoteMedia.note_id.in_(
        db.query(Note.id).filter(Note.created_by == target.id))).delete(synchronize_session=False)
    db.query(Note).filter(Note.created_by == target.id).delete()
    # 删除频道（如果有 user 关联）
    try:
        db.query(Channel).filter(Channel.created_by == target.id).delete()
    except Exception:
        pass
    db.delete(target)
    db.commit()
    return ok(msg=f"已删除会员 {target.username} 及其所有数据")
